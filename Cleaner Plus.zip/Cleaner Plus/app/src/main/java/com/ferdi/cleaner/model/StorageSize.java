package com.ferdi.cleaner.model;

public class StorageSize {
    public String suffix;
    public float value;
}
