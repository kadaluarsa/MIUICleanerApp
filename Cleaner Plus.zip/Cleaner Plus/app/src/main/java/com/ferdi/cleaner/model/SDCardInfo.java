package com.ferdi.cleaner.model;

public class SDCardInfo {
    public long free;
    public long total;
}
