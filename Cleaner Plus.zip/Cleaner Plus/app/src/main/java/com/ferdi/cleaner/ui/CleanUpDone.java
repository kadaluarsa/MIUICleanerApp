package com.ferdi.cleaner.ui;

import android.app.Activity;
import android.os.Bundle;

import com.ferdi.cleanerr.R;


public class CleanUpDone extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cleanup_done);
    }
}
